package com.example.demo1.service;

import java.util.List;

import com.example.demo1.model.Quiz;

public interface QuizService {
	public List<Quiz> getAllQuiz();
}
