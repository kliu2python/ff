package com.example.demo1.DAO;

import java.util.List;

import com.example.demo1.model.Quiz;

public interface QuizDAO {
	public List<Quiz> getAllQuizs();
}
